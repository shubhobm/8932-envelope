#define FLOPS_DIV 8
#define FLOPS_SQRT 8
#define FLOPS_EXP 40
#define FLOPS_LOG 20

void addflops(unsigned fl);

