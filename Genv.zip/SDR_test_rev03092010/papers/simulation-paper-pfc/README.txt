################################################################################

LDR: a software package for likelihood based sufficient dimension reduction
        
                by R.D. Cook, L. Forzani and D. Tomassi
                            
                               2009
                
################################################################################

This folder contains scripts to reproduce tables and figures 
from the paper by R. D. Cook and L. Forzani: 
"Principal Fitted components in Regression". 
 To appear.

################################################################################
